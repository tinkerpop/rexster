Place all extension jars (and their dependencies) in this directory and they will be loaded when ReXster is started.
Be sure that they are also activated in the rexster.xml configuration file and listed in com.tinkerpop.rexster.extension.RexsterExtension in main/resources/META-INF/services.
