package com.tinkerpop.rexster.config;

public class SparqlRepositorySailGraphConfiguration extends AbstractSailGraphConfiguration {
    public SparqlRepositorySailGraphConfiguration() {
        this.sailType = AbstractSailGraphConfiguration.SAIL_TYPE_SPARQL;
    }
}
