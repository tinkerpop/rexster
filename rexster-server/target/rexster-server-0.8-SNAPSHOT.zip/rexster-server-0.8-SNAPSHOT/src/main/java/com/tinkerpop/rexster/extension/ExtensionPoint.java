package com.tinkerpop.rexster.extension;

public enum ExtensionPoint {
    GRAPH,
    VERTEX,
    EDGE
}
