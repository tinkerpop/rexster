package com.tinkerpop.rexster.kibbles.sample;

import com.tinkerpop.rexster.extension.AbstractRexsterExtension;

/**
 * Base class for samples.
 */
public abstract class AbstractSampleExtension extends AbstractRexsterExtension {
    public static final String EXTENSION_NAMESPACE = "tp-sample";
}
